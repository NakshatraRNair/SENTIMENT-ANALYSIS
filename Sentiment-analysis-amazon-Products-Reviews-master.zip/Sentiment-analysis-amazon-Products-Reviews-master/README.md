# Sentiment-analysis-amazon-Products-Review
Sentiment analysis model on amazon Products Reviews
Data : From the Multi-Domain Sentiment Dataset (version 2.0): 25 product reviews on amazon products : ([unprocessed.tar.gz])
www.cs.jhu.edu/~mdredze/datasets/sentiment/

Link to download the data:
http://www.cs.jhu.edu/~mdredze/datasets/sentiment/unprocessed.tar.gz (1.5 G)

# For Deployment i used Heroku and django framwork:
you can test the model with real time prediction being generated.
LINK For Django Project :
https://github.com/alaBay94/SentimentAnalysis
![alt text](https://github.com/alaBay94/Sentiment-analysis-amazon-Products-Reviews/blob/master/Site.PNG)
LINK WebSite :
https://pure-island-69328.herokuapp.com/
